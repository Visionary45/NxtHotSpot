package com.example.nxthotspot;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login_Screen extends AppCompatActivity {

    TextView fgtpass;
    Button btnReg;
    Button btnSign;
    Button btnLog;
    private static String Mail;
    private static String Pass;
    private static FirebaseAuth mAuth;
    private static CheckBox checkBox;
    public static SharedPreferences preferences;
    private EditText usermail;
    private EditText userpass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        mAuth = FirebaseAuth.getInstance();

        fgtpass = findViewById(R.id.txtResPass);

        btnSign = findViewById(R.id.btnLogin);

        btnReg = findViewById(R.id.btnRg);

        usermail = findViewById(R.id.txtemail);
        userpass = findViewById(R.id.pass);

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login_Screen.this, Register_Screen.class);
                startActivity(intent);
                finish();
            }
        });

        btnSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),"User Successfully logged On...", Toast.LENGTH_SHORT).show();
                Intent loggedInUser = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(loggedInUser);
                finish();
                //userLogin();
            }
        });

        fgtpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(), PassRest.class);
                startActivity(in);
            }
        });
    }

    private void userLogin() {
        Mail = usermail.getText().toString();
        Pass = userpass.getText().toString();

        if (!Mail.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(Mail).matches()) {
            if (!Pass.isEmpty()) {
                mAuth.signInWithEmailAndPassword(Mail,Pass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(getApplicationContext(),"User Successfully logged On...", Toast.LENGTH_SHORT).show();
                        Intent loggedInUser = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(loggedInUser);
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "Invalid user Email and Password", Toast.LENGTH_LONG).show();
                    }
                });
            } else {
                userpass.setError("Empty Fields are not allowed");
            }
        } else if (Mail.isEmpty()) {
            usermail.setError("Empty Fields are not allowed");
        }else{
            usermail.setError("Please Enter Correct Email");
        }
        //validatoin for password
        if (!Pass.isEmpty()) {
            if (!Mail.isEmpty()) {

            } else {
                usermail.setError("Empty Fields are not allowed");
            }
        } else if (Pass.isEmpty()) {
            userpass.setError("Empty Fields are not allowed");
        }else{
            userpass.setError("Invalid user Password");
        }

    }
}