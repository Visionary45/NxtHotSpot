package com.example.nxthotspot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Welcome extends AppCompatActivity {

    private Button btnO;
    SharedPreferences prefs;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        btnO = findViewById(R.id.btnOpn);


        btnO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Login_Screen.class);
                startActivity(i);
                finish();
                prefs = getSharedPreferences("start", MODE_PRIVATE);
                editor = prefs.edit();
                editor.putBoolean("firstStart", false);
                editor.apply();
                finish();
            }
        });
    }
}