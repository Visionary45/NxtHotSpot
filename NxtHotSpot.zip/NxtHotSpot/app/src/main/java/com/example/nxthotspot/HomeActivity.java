package com.example.nxthotspot;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HomeActivity extends Fragment implements OnMapReadyCallback {
    public String placeSearch = "",  placeNAme ="";
    Activity Main;
    private Location currentLocation;
    private int radius = 5000;
    private int zoomLevel = 16;
    public static String place_id;
    public static double lat;
    public static double lng;
    private  double latitude;
    private double longitude;
    private FusedLocationProviderClient client;
    private RecyclerView placesDetails;
    private ArrayList<PlaceSearch> placeS;
    InfoWindowAdapter infoWindowAdapter;
    ImageView saveLoc, directLoc;
    CardView placeItem;
    Marker currentMaker;
    GoogleMap mGoogleMap;
    ShimmerFrameLayout shimmer;
    private AppPermission appPermission;
    LocationRequest locationRequest;
    LocationCallback locationCallback;
    FloatingActionButton btnCurrent;
    TextInputEditText txtCityN;

    public HomeActivity(){

    }

    private void setupMap() {
        if(ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) !=
        PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            return;
        }
        mGoogleMap.setMyLocationEnabled(false);
        mGoogleMap.getUiSettings().setTiltGesturesEnabled(false);
        setUpLocationUpdates();
    }

    private void setUpLocationUpdates() {
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(locationRequest.PRIORITY_HIGH_ACCURACY);
        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if(locationResult != null){
                    for(Location location : locationResult.getLocations()){
                        Log.d("TAG", "Location Res: "+ location.getLongitude()+" "+location.getLatitude());
                    }
                }
                super.onLocationResult(locationResult);
            }
        };
        client = LocationServices.getFusedLocationProviderClient(requireContext());
        startLocaionUDates();
    }

    private void startLocaionUDates() {
        if(ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            return;
        }
        client.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                           // Toast.makeText(requireContext(), "User Location Updated", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        getCurrentLoc();
    }

    private void getCurrentLoc() {
        FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext());
        if(ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            return;
        }
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                currentLocation = location;
                moveCameraToLoc(location);
                if(location != null){
                    latitude = Math.round(location.getLatitude() * 100.00)/ 100.0;

                    longitude = Math.round(location.getLongitude() * 100.00)/ 100.0;
                    if(placeSearch != null){

                        txtCityN.setText(placeSearch);
                        txtCityN.getText().toString();
                        getPlaces(txtCityN.getText().toString());
                    }else{
                        txtCityN.setText(placeNAme);
                        txtCityN.getText().toString();
                        getPlaces(txtCityN.getText().toString());
                    }

                }else{

                }
            }
        });

    }

    private void moveCameraToLoc(Location location) {
        int height = 90, width = 60;
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new
                LatLng(location.getLatitude() , location.getLongitude()),16);
        Bitmap getImage = BitmapFactory.decodeResource(getResources(), R.drawable.logo2);
        Bitmap icon = Bitmap.createScaledBitmap(getImage, width, height , false);
        MarkerOptions markerOptions = new MarkerOptions()
                .position(new LatLng(location.getLatitude(), location.getLongitude()))
                .title("User Position")
                .icon(BitmapDescriptorFactory.fromBitmap(icon));
        if(currentMaker != null){
            currentMaker.remove();
        }
        currentMaker = mGoogleMap.addMarker(markerOptions);
        currentMaker.setTag(101);
        mGoogleMap.animateCamera(cameraUpdate);
    }
    private void stopLocUpdate(){
        client.removeLocationUpdates(locationCallback);
        Log.d("TAG", "stopping location updates ");
    }

    @Override
    public void onPause() {
        super.onPause();
        if(client != null){
            stopLocUpdate();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if(client != null){
            startLocaionUDates();
            if(currentMaker != null){
                currentMaker.remove();
            }
        }
    }

    private void requestLocation() {
        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
        ,Manifest.permission.ACCESS_BACKGROUND_LOCATION}, 1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 1){
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                setupMap();
            }else{
                Toast.makeText(requireContext(),"Location Not Granted, Please enabled it", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home_activity, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
        appPermission = new AppPermission();

        placeItem = view.findViewById(R.id.itemCard);
        placesDetails =(RecyclerView) view.findViewById(R.id.placesRecyclerView);
        placeS = new ArrayList<>();
        Intent searchData = getActivity().getIntent();
        Intent pName = getActivity().getIntent();
        placeSearch = searchData.getStringExtra("LANDMARK");
        placeNAme = pName.getStringExtra("placeName");
        Toast.makeText(getContext(), placeNAme, Toast.LENGTH_SHORT).show();
        recyclerviewMethod();
        shimmer = (ShimmerFrameLayout) view.findViewById(R.id.shimmerLayout);
        SnapHelper snapHelper = new LinearSnapHelper();
        Handler mainHandler = new Handler(Looper.getMainLooper());
        snapHelper.attachToRecyclerView(placesDetails);
        txtCityN = view.findViewById(R.id.txtcityEdit);
        txtCityN.setText(placeSearch);
        btnCurrent = view.findViewById(R.id.btnCurrentLoc);
        btnCurrent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startLocaionUDates();
            }
        });
        recyclerviewMethod();
    }

    private void recyclerviewMethod() {
        infoWindowAdapter = new InfoWindowAdapter(requireContext(), placeS);
        placesDetails.setLayoutManager(new LinearLayoutManager(requireContext(),
                LinearLayoutManager.HORIZONTAL, false));
        placesDetails.setHasFixedSize(false);
        placesDetails.setAdapter(infoWindowAdapter);
    }

    public void getPlaces(String Name){
        String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="
                + latitude + "," + longitude
                + "&radius=" + radius + "&keyword=" + Name + "&key=" +
                getResources().getString(R.string.API_KEY);
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d("Error", "Request Failed");
            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if(!response.isSuccessful()){
                    throw new IOException("Error : "+ response);
                }else{
                    Log.d("Error", "Request Successful.");
                }
                String res =  response.body().string();
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(new Runnable() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void run() {
                        shimmer.startShimmer();
                        try{
                            JSONObject object = new JSONObject(res);
                            JSONArray arr = object.getJSONArray("results");
                            for(int i = 0; i <arr.length(); i++){
                                JSONObject PlaceD = arr.getJSONObject(i);
                                JSONObject place = PlaceD.getJSONObject("geometry");
                                JSONObject  loc  = place.getJSONObject("location");
                                String Address = PlaceD.getString("vicinity");
                                String pName  = PlaceD.getString("name");
                                String Rating  = PlaceD.getString("rating");
                                String icon  = PlaceD.getString("icon");
                                lat = loc.getDouble("lat");
                                lng = loc.getDouble("lng");
                                place_id = PlaceD.getString("place_id");
                                placeS.add(new PlaceSearch(pName, Address, icon, Rating,place_id,lat,lng));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("Check ", e.getMessage());
                        }
                        shimmer.stopShimmer();
                        recyclerviewMethod();
                    }
                });
            }
        });
    }
    public void setRecyclerViewMarker(){

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mGoogleMap = googleMap;
        if(appPermission.isLocationOk(requireContext())){
            setupMap();
        }else if(ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), ACCESS_FINE_LOCATION)){
            new AlertDialog.Builder(requireContext())
                    .setTitle("Location Permission Required")
                    .setMessage("Application needs you to grant location to continue..")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            requestLocation();
                        }
                    }).create().show();
        }else{
            requestLocation();
        }
    }
    public void getPlaceD(String Name){
        String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="
                + latitude + "," + longitude
                + "&radius=" + radius + "&keyword=" + Name + "&key=" +
                getResources().getString(R.string.API_KEY);
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d("Error", "Request Failed");
            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if(!response.isSuccessful()){
                    throw new IOException("Error : "+ response);
                }else{
                    Log.d("Error", "Request Successful.");
                }
                String res =  response.body().string();
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(new Runnable() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void run() {
                        shimmer.startShimmer();
                        try{
                            JSONObject object = new JSONObject(res);
                            JSONArray arr = object.getJSONArray("results");
                            for(int i = 0; i <arr.length(); i++){
                                JSONObject PlaceD = arr.getJSONObject(i);
                                JSONObject place = PlaceD.getJSONObject("geometry");
                                JSONObject  loc  = place.getJSONObject("location");
                                String Address = PlaceD.getString("vicinity");
                                String pName  = PlaceD.getString("name");
                                String Rating  = PlaceD.getString("rating");
                                String icon  = PlaceD.getString("icon");
                                lat = loc.getDouble("lat");
                                lng = loc.getDouble("lng");
                                place_id = PlaceD.getString("place_id");
                                placeS.add(new PlaceSearch(pName, Address, icon, Rating,place_id,lat,lng));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("Check ", e.getMessage());
                        }
                        shimmer.stopShimmer();
                        recyclerviewMethod();
                    }
                });
            }
        });
    }
}