package com.example.nxthotspot;

public class PlaceSearch {
    private String placeName;
    private String Address;
    private String Icon;
    private String Ratings;
    private String place_id;
    private double lat;
    private double lng;

    public PlaceSearch(String placeName, String address, String icon, String ratings, String place_id, double lat, double lng) {
        this.placeName = placeName;
        Address = address;
        Icon = icon;
        Ratings = ratings;
        this.place_id = place_id;
        this.lat = lat;
        this.lng = lng;
    }

    public String getPlaceName() {
        return placeName;
    }

    public void setPlaceName(String placeName) {
        this.placeName = placeName;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getIcon() {
        return Icon;
    }

    public void setIcon(String icon) {
        Icon = icon;
    }

    public String getRatings() {
        return Ratings;
    }

    public void setRatings(String ratings) {
        Ratings = ratings;
    }

    public String getPlace_id() {
        return place_id;
    }

    public void setPlace_id(String place_id) {
        this.place_id = place_id;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }
}
