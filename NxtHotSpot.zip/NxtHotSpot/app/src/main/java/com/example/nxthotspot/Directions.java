package com.example.nxthotspot;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.viewpager.widget.ViewPager;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.tabs.TabLayout;
import com.google.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Directions extends AppCompatActivity implements OnMapReadyCallback {
    String place_id = "", placename = "", mode = "";
    double lat = 0, lng = 0;
    EditText txtCrrnt, txtDestination;
    Location currentLoc;
    private ViewPager viewPager;
    private TabLayout tabLayout;
    SupportMapFragment mapFragment;
    GoogleMap mGoogleMap;
    CoordinatorLayout coordinatorLayout;
    BottomSheetBehavior bottomSheetBehavior;
    private AppPermission appPermissions;
    ShimmerFrameLayout ShimmerFrameLayout;
    DirectionAdapter adapter;
    private int radius = 5000;
    ChipGroup chipGroup;
    private ArrayList<DirectionClass> DirectionsRes;
    public List path;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directions);
        appPermissions = new AppPermission();

        coordinatorLayout = findViewById(R.id.bottom_layout);

        Intent directionData = getIntent();
        place_id = directionData.getStringExtra("place_id");
        placename = directionData.getStringExtra(getString(R.string.p_name));
        lat = directionData.getDoubleExtra("lat", lat);
        lng = directionData.getDoubleExtra("lng", lng);

        txtCrrnt = findViewById(R.id.txtCurrent);
        txtDestination = findViewById(R.id.txtDesti);
        txtDestination.setText(placename);
        DirectionsRes = new ArrayList<>();
        path = new ArrayList<>();

        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.dMap);

        mapFragment.getMapAsync(this);

        chipGroup = findViewById(R.id.travelOptions);
        chipGroup.setOnCheckedChangeListener(new ChipGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(ChipGroup group, int checkedId) {
                if(checkedId == R.id.btnDriving){
                    getDirection("@string/driving");
                }else if(checkedId == R.id.btnWalking){
                    getDirection("@string/walking");
                }else if(checkedId == R.id.btnTrain){
                    getDirection("@string/transit");
                }else if(checkedId == R.id.btnBike){
                    getDirection("@string/bike");
                }
            }
        });
        getBottomSheet();
    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mGoogleMap = googleMap;
        if(appPermissions.isLocationOk(this)){
            googleMapSetup();
        }else{
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)){
                new AlertDialog.Builder(this)
                        .setTitle("GPS Location Permission")
                        .setMessage("Pleas enable the location to get nearby searches")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                appPermissions.requestLocationPermission(Directions.this);
                            }
                        }).create().show();
            }else{
                appPermissions.requestLocationPermission(Directions.this);
            }
        }
    }

    private void googleMapSetup() {
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        != PackageManager.PERMISSION_GRANTED ){
            return;
        }

        mGoogleMap.setMyLocationEnabled(true);
        mGoogleMap.getUiSettings().setTiltGesturesEnabled(true);
        mGoogleMap.getUiSettings().setMyLocationButtonEnabled(false);
        mGoogleMap.getUiSettings().setCompassEnabled(false);

        getCurrentLoc();
    }

    private void getCurrentLoc() {
        FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null){
                    currentLoc = location;
                    getDirection("Driving");
                }else{
                    Toast.makeText(getApplicationContext(), "Location Not Found" , Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void getDirection(String mode){
        String url = "https://maps.googleapis.com/maps/api/directions/json?origin="+
                currentLoc.getLatitude() + "," + currentLoc.getLongitude()
                + "&destination=" + lat +","+ lng + "&mode=" + mode + "&key=" +
                getResources().getString(R.string.API_KEY);
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                Log.d("Error", "Request Failed");
            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if(!response.isSuccessful()){
                    throw new IOException("Error : "+ response);
                }else{
                    Log.d("Error", "Request Successful.");
                }
                String res =  response.body().string();
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(new Runnable() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void run() {
                        //ShimmerFrameLayout.startShimmer();
                        try{
                            JSONObject object = new JSONObject(res);
                            JSONArray arr = object.getJSONArray("routes");
                            JSONObject routes = arr.getJSONObject(0);
                            JSONArray routesData = routes.getJSONArray("legs");
                            JSONObject legs = routesData.getJSONObject(0);
                            JSONArray legsData = legs.getJSONArray("steps");
                            for(int i  = 0; i < legsData.length(); i++){

                                JSONObject getData = legsData.getJSONObject(i);
                                JSONObject dist = getData.getJSONObject("distance");
                                JSONObject dis = getData.getJSONObject("distance");
                                JSONObject startLoc = getData.getJSONObject("start_location");
                                JSONObject endLoc = getData.getJSONObject("end_location");
                                String distance = dist.getString("text");
                                JSONObject d = getData.getJSONObject("duration");
                                String duration = d.getString("text");
                                JSONObject polyline = getData.getJSONObject("polyline");
                                String polyLinePoint = polyline.getString("points");
                                double startLocLat = startLoc.getDouble("lat");
                                double startLocLng = startLoc.getDouble("lng");
                                double endLocLat = endLoc.getDouble("lat");
                                double endLocLng = endLoc.getDouble("lng");
                                double startLocData = startLocLat + startLocLng;
                                double endtLocData = endLocLat + endLocLng;

                                List<LatLng> list = decodePolyLine(polyLinePoint);
                                String steps ="";
                                String StartAddr = legs.getString("end_address");
                                String EndAddr =  legs.getString("start_address");
                                String html_instructions = getData.getString("html_instructions");
                                DirectionsRes.add(new DirectionClass(distance, startLocData,endtLocData, duration,steps, StartAddr,EndAddr ));
                                Toast.makeText(getApplicationContext(), duration, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Log.d("Check ", e.getMessage());
                        }
                       // ShimmerFrameLayout.stopShimmer();
                    }
                });
            }
        });
    }
    public void getBottomSheet(){
        bottomSheetBehavior = BottomSheetBehavior.from(coordinatorLayout);

        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);

        bottomSheetBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {

            }


            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });
    }
    private List<LatLng> decodePolyLine(final String poly) {
        int len = poly.length();
        int index = 0;
        List<LatLng> decoded = new ArrayList<LatLng>();
        int Lat = 0;
        int Lng = 0;
        while (index < len) {
            int b;
            int shift = 0;
            int result = 0;
            do {
                b = poly.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            Lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = poly.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            Lng += dlng;

            decoded.add(new LatLng(
                    Lat / 100000d, Lng / 100000d
            ));
        }
        return decoded;
    }

    /* public static PlaceDetailsRequest placeDetails(GeoApiContext geoApiContext, String placeid){

    }

    */
}