package com.example.nxthotspot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;

import androidx.appcompat.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {
    SharedPreferences prefs;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //first load preference

        prefs = getSharedPreferences("start", MODE_PRIVATE);
        boolean firstStart = prefs.getBoolean("firstStart", true);
        if(firstStart)
        {
            showStartPage();
        }else{
            showLoginAct();
        }


        //theme method
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String dark_white_theme = sharedPreferences.getString("dark_white_theme", ThemeHelper.DEFAULT_MODE);
        ThemeHelper.applyTheme(dark_white_theme);
    }
    private void showStartPage() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Welcome.class);
                startActivity(intent);
                finish();
            }
        }, 1000);
    }
    private void showLoginAct(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent lognP = new Intent(getApplicationContext(), Login_Screen.class);
                startActivity(lognP);
                finish();
            }
        }, 1000);
    }
}
