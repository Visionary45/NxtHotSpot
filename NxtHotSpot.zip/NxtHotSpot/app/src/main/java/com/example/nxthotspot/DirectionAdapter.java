package com.example.nxthotspot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DirectionAdapter extends RecyclerView.Adapter<DirectionAdapter.ViewHolder> {
    private Context context;
    private ArrayList<DirectionClass> directionRes;

    public DirectionAdapter(Context context, ArrayList<DirectionClass> directionres) {
        this.context = context;
        this.directionRes = directionres;
    }
    @NonNull
    @Override
    public DirectionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.step_item_layout, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DirectionAdapter.ViewHolder holder, int position) {
        DirectionClass res = directionRes.get(position);
        holder.txtStp.setText(res.getStep());
        holder.txtTime.setText(res.getDuration());
        holder.txtDistance.setText(res.getDistance());
    }

    @Override
    public int getItemCount() {
        return directionRes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtStp, txtTime, txtDistance;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtStp = itemView.findViewById(R.id.txtStep);
            txtTime = itemView.findViewById(R.id.txtStepTime);
            txtDistance = itemView.findViewById(R.id.txtStepDistance);
        }
    }
}
