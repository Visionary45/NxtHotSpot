package com.example.nxthotspot;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceManager;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.settings, new SettingsFragment())
                    .commit();
        }
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

    }
    //fragment code
    public static class SettingsFragment extends PreferenceFragmentCompat {

        final static String TAG = "SettingsFragmentTag";
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
            ListPreference themePreference = findPreference("dark_white_theme");
            if (themePreference != null){
                themePreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                    @Override
                    public boolean onPreferenceChange(Preference preference, Object newValue) {
                        String themeOptions = (String) newValue;
                        ThemeHelper.applyTheme(themeOptions);
                        return true;
                    }
                });
            }

            ListPreference metricSyst = findPreference("distance_metrics");
            if(metricSyst != null){
                metricSyst.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                    @Override
                    public boolean onPreferenceChange(Preference preference, Object newValue) {
                        String Metric = (String) newValue;
                        MetricSetting.GetMetricSettings(Metric);
                        return true;
                    }
                });
            }
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
    public Context getContext(){
        Context mContext = SettingsActivity.this;
        return mContext;
    }
}
class MetricSetting{
    public static String Metric = "";
    public static final String Miles = "Miles";
    public static final String Kilometers = "KM";
    public static final String DEFAULT = "Select one of the System";

    public static void GetMetricSettings(@NonNull String distance_metrics ){
        switch(distance_metrics){
            case Miles:{
                Metric = Miles;
                break;
            }
            case Kilometers:{
                Metric = Kilometers;
                break;
            }
            default:{
                Metric =DEFAULT;
                break;
            }
        }
    }
}