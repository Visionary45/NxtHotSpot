package com.example.nxthotspot;

public class DirectionClass {
    String distance;
    double endLocation;
    double startLocation;
    String duration,  Step;
    String startAddress, EndAddress ;

    public DirectionClass(String distance, double endLocation, double startLocation, String duration, String step, String startAddress, String endAddress) {
        this.distance = distance;
        this.endLocation = endLocation;
        this.startLocation = startLocation;
        this.duration = duration;
        this.Step = step;
        this.startAddress = startAddress;
        this.EndAddress = endAddress;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public double getEndLocation() {
        return endLocation;
    }

    public void setEndLocation(double endLocation) {
        this.endLocation = endLocation;
    }

    public double getStartLocation() {
        return startLocation;
    }

    public void setStartLocation(double startLocation) {
        this.startLocation = startLocation;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getStep() {
        return Step;
    }

    public void setStep(String step) {
        Step = step;
    }

    public String getStartAddress() {
        return startAddress;
    }

    public void setStartAddress(String startAddress) {
        this.startAddress = startAddress;
    }

    public String getEndAddress() {
        return EndAddress;
    }

    public void setEndAddress(String endAddress) {
        EndAddress = endAddress;
    }
}
