package com.example.nxthotspot;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Register_Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);
    }
}