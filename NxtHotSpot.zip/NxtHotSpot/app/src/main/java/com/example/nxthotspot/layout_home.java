package com.example.nxthotspot;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.preference.PreferenceManager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;

class layout_home extends AppCompatActivity {

    ImageButton btnpark, btnCffe, btnShpp, btnTrn, btnDnng, btnDrnkPlc;
    String [] Landmark_Type = { "Coffee","Store","Transit","Resturants","Bars"};
    String Park = "Park";
    EditText placeSearch;
    //drawer
    DrawerLayout drawerLayout;
    Button btnSch;
    GridLayout places;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_home);
        drawerLayout = findViewById(R.id.drawer_layout);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String dark_white_theme = sharedPreferences.getString("dark_white_theme", ThemeHelper.DEFAULT_MODE);
        ThemeHelper.applyTheme(dark_white_theme);

        btnpark = findViewById(R.id.parks);
        btnCffe = findViewById(R.id.cffeespot);
        btnDnng = findViewById(R.id.Dining);
        btnTrn = findViewById(R.id.trans);
        btnShpp =findViewById(R.id.shoppng);
        btnDrnkPlc = findViewById(R.id.drnkplc);

    }

    public void ClickMenu(View view){
        //open Drawer
        MainActivity.openDrawer(drawerLayout);
    }
    public void ClickLogout(View view){
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }
    public void ClickHome(View view){
        //opening the home activity
        recreate();
    }

    public void ClickSettings(View view){
        //redirect to about us activity
        MainActivity.redirectActivity(this, SettingsActivity.class);
    }
    public void ClickLogo(View view){
        //close the application
        MainActivity.logout(this);
    }
    public void ClickDining(View view) {
        Intent Restaurants = new Intent(getApplicationContext(), MapData.class);
        Restaurants.putExtra("LANDMARK", "Restaurants");
        startActivity(Restaurants);
    }
    public void ClickDialog(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());
        View v = getLayoutInflater().inflate(R.layout.dialog_place,null);
        final EditText plcName = (EditText) v.findViewById(R.id.edtPlaceNme);
        Button btnSrch = (Button) v.findViewById(R.id.btnSrchN);
        Button btnCncl = (Button) v.findViewById(R.id.btnCnclSrch);
        builder.setView(v);
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();

        btnSrch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        btnCncl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

    }
    public void ClickParks(View view)
    {
        Intent park = new Intent(getApplicationContext(), MapData.class);
        park.putExtra("LANDMARK", "Parks");
        startActivity(park);
    }
    public void ClickTrans(View view){
        Intent trans = new Intent(getApplicationContext(), MapData.class);
        trans.putExtra("LANDMARK", "transit");
        startActivity(trans);
    }
    public void ClickCafe(View view){
        Intent cafe = new Intent(getApplicationContext(), MapData.class);
        cafe.putExtra("LANDMARK", "Cafe");
        startActivity(cafe);
    }
    public void ClickBar(View view){
        Intent bar = new Intent(getApplicationContext(), MapData.class);
        bar.putExtra("LANDMARK", "Bars");
        startActivity(bar);
    }
    public void ClickShops(View view)
    {
        Intent Shops = new Intent(getApplicationContext(), HomeActivity.class);
        Shops.putExtra("LANDMARK", "Stores");
        startActivity(Shops);
    }
    @Override
    protected void onPause(){
        super.onPause();
        //close drawer
        MainActivity.closeDrawer(drawerLayout);
    }
}