package com.example.nxthotspot;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.textview.MaterialTextView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class InfoWindowAdapter extends RecyclerView.Adapter<InfoWindowAdapter.Viewholder> {
    private Context context;
    private ArrayList<PlaceSearch> placeResults;
    double lat = 0, lng = 0;
    String place_id = "";
    public InfoWindowAdapter(Context context, ArrayList<PlaceSearch> placeResults) {
        this.context = context;
        this.placeResults = placeResults;
    }
    @NonNull
    @Override
    public InfoWindowAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.place_item_layout, parent,false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InfoWindowAdapter.Viewholder holder,  int position) {
        PlaceSearch res = placeResults.get(position);
        holder.txtName.setText(res.getPlaceName());
        holder.txtAddr.setText(res.getAddress());
        holder.txtRtngs.setText(res.getRatings());
        holder.txtId.setText(res.getPlace_id());
        holder.txtLn.setText(" "+ res.getLng());
        holder.txtLt.setText(" "+ res.getLat());
        holder.txtRtngs.setText(res.getRatings());
        Picasso.get().load(res.getIcon()).into(holder.imgDis);

        lat = placeResults.get(position).getLat();
        lng = placeResults.get(position).getLng();
        place_id = placeResults.get(position).getPlace_id();

        holder.btnDirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent directions = new Intent(context.getApplicationContext(), Directions.class);
                directions.putExtra("lat",res.getLat());
                directions.putExtra("lng",res.getLng());
                directions.putExtra("place_id",res.getPlace_id());
                directions.putExtra("Placename",res.getPlaceName());
                context.startActivity(directions);
            }
        });
    }

    @Override
    public int getItemCount() {

        return placeResults.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        private ImageView imgDis,btnDirect;
        private TextView txtName, txtAddr,txtLt, txtLn, txtId;
        private MaterialTextView txtRtngs;

        public Viewholder(@NonNull View itemView) {
            super(itemView);
            imgDis = itemView.findViewById(R.id.imgPLce);
            txtName = itemView.findViewById(R.id.txtPlaceName);
            txtAddr = itemView.findViewById(R.id.txtPlaceAddress);
            txtLt = itemView.findViewById(R.id.txtLat);
            txtLn = itemView.findViewById(R.id.txtlng);
            txtId = itemView.findViewById(R.id.txtPID);
            txtRtngs = itemView.findViewById(R.id.txtPlaceDRating);
            ImageView btnSloc = (ImageView) itemView.findViewById(R.id.imgSaveLocation);
            ImageView btnRmveSave = (ImageView) itemView.findViewById(R.id.imgSavedLocation);
            btnDirect = (ImageView) itemView.findViewById(R.id.imgDirec);

            btnSloc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btnSloc.setVisibility(View.GONE);
                    btnRmveSave.setVisibility(View.VISIBLE);
                }
            });
            btnRmveSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btnRmveSave.setVisibility(View.GONE);
                    btnSloc.setVisibility(View.VISIBLE);
                }
            });
        }
    }
}
