package com.example.nxthotspot;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.preference.PreferenceManager;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Toolbar mytb;
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private static final int Request_User_Location_Code = 99;
    ImageButton btnImg;

    private SavedPlaces savedPlaces;
    private Home homeFrag;
    String placeName;

    DrawerLayout drawerLayout;

    private AppPermission appPermission;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout_home home = new layout_home();
        AppCompatDelegate rootView = null;

        appPermission = new AppPermission();
        appPermission.requestLocationPermission(MainActivity.this);
        //theme method
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String dark_white_theme = sharedPreferences.getString("dark_white_theme", ThemeHelper.DEFAULT_MODE);
        ThemeHelper.applyTheme(dark_white_theme);


        mytb = findViewById(R.id.my_toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);

        setSupportActionBar(mytb);

        final ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);

        viewPager = findViewById(R.id.view_pager);

        tabLayout = findViewById(R.id.tab_layout);

        savedPlaces = new SavedPlaces();
        homeFrag = new Home();

        tabLayout.setupWithViewPager(viewPager);
        int behaviour = 0;
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), behaviour);
        viewPagerAdapter.addFragment(homeFrag,"Home" );
        viewPagerAdapter.addFragment(savedPlaces, "Saved Places");
        viewPager.setAdapter(viewPagerAdapter);
        tabLayout.getTabAt(0).setIcon(R.drawable.ic_home);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_geolocation_icon_5);

    }
    private class ViewPagerAdapter extends FragmentPagerAdapter {
        private List<Fragment> fragments = new ArrayList<>();
        private List<String> titles = new ArrayList<>();

        public ViewPagerAdapter(@NonNull FragmentManager fm, int behaviour) {
            super(fm, behaviour);
        }

        public void addFragment(Fragment fragment, String Title){
            fragments.add(fragment);
            titles.add(Title);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }
    }

    public  void ClickLogo(View view){
        //close drawer
        closeDrawer(drawerLayout);
    }

    public void ClickDialog(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View v = getLayoutInflater().inflate(R.layout.dialog_place,null);
        View parent = findViewById(R.id.layoutHome);
        btnImg = (ImageButton) findViewById(R.id.imgDialog);
        final EditText plcName = (EditText) v.findViewById(R.id.edtPlaceNme);
        String placeSName = plcName.getText().toString();
        Button btnSrch = (Button) v.findViewById(R.id.btnSrchN);
        Button btnCncl = (Button) v.findViewById(R.id.btnCnclSrch);
        builder.setView(v);
        final AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();
        if(alertDialog.isShowing()){
            btnImg.setImageResource(R.drawable.ic_arrow_down);
        }
        btnSrch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent search = new Intent(getApplicationContext(), MapData.class);
                search.putExtra("placeName", plcName.getText().toString());
                startActivity(search);
                alertDialog.dismiss();
                btnImg.setImageResource(R.drawable.ic_arrow_up);
            }
        });
        btnCncl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnImg.setImageResource(R.drawable.ic_arrow_up);
                alertDialog.dismiss();
            }
        });

    }

    public static void closeDrawer(DrawerLayout drawerLayout) {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            //close drawer if open
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }
    public void ClickHome(View view){
        recreate();
    }

    public void ClickSettings(View view){
        //redirect to about us activity
        redirectActivity(this,SettingsActivity.class);
    }
    public void ClickLogout(View view){
        //close the app
        logout(this);
    }
    public void ClickDining(View view) {
        placeName = "restaurant";
        Intent search = new Intent(getApplicationContext(), MapData.class);
        search.putExtra("LANDMARK", placeName);
        setResult(Activity.RESULT_OK, search);
        startActivity(search);
    }
    public void ClickParks(View view)
    {
        Intent park = new Intent(getApplicationContext(), MapData.class);
        park.putExtra("LANDMARK", "park");
        startActivity(park);
    }
    public void ClickTrans(View view){
        Intent trans = new Intent(getApplicationContext(), MapData.class);
        trans.putExtra("LANDMARK", "gas_station");
        startActivity(trans);
    }
    public void ClickCafe(View view){
        Intent cafe = new Intent(getApplicationContext(), MapData.class);
        cafe.putExtra("LANDMARK", "cafe");
        startActivity(cafe);
    }
    public void ClickBar(View view){
        Intent bar = new Intent(getApplicationContext(), MapData.class);
        bar.putExtra("LANDMARK", "bar");
        startActivity(bar);
    }
    public void ClickShops(View view)
    {
        Intent Shops = new Intent(getApplicationContext(), MapData.class);
        Shops.putExtra("LANDMARK", "supermarket");
        startActivity(Shops);
    }


    public static void openDrawer(DrawerLayout drawerLayout) {
        //open drawer layout
        drawerLayout.openDrawer(GravityCompat.START);
    }
    public static void logout(Activity activity) {
        //initialize alet dialogue
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        //set dialogue title
        builder.setTitle("Logout");
        //set Message
        builder.setMessage("Are you sure you want to Logout..?");
        //Positive button click
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //finish activity
                activity.finishAffinity();
                //exit application
                System.exit(0);
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }
    public static void redirectActivity(Activity activity, Class aClass) {
        //Initialize intent
        Intent intent = new Intent(activity,aClass);
        //set flag
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        // start the activity

        activity.startActivity(intent);
    }
    @Override
    protected void onPause(){
        super.onPause();
        //Close drawer
        closeDrawer(drawerLayout);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public boolean checkUserPermission(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(
                    this, Manifest.permission.ACCESS_FINE_LOCATION)){
                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION}, Request_User_Location_Code);
            }
            return false;
        }else{
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
